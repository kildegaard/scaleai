import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;
import java.util.List;

public class LargeCSVMovingAverage {

    private static final int WINDOW_SIZE = 30; // Moving average window size
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public static void main(String[] args) throws IOException {
        if (args.length != 2) {
            System.out.println("Usage: java LargeCSVMovingAverage <input_file.csv> <output_file.csv>");
            return;
        }

        String inputFile = args[0];
        String outputFile = args[1];

        calculateMovingAverage(inputFile, outputFile);
    }

    public static void calculateMovingAverage(String inputFile, String outputFile) throws IOException {
        try (CSVReader reader = new CSVReader(new FileReader(inputFile));
             CSVWriter writer = new CSVWriter(new FileWriter(outputFile))) {

            // Write header row to output file
            String[] header = reader.readNext();
            writer.writeNext(header);

            // Data structures for moving average calculation
            Deque<LocalDate> dateWindow = new ArrayDeque<>();
            Deque<double[]> valueWindow = new ArrayDeque<>();
            double[] sumValues = null;

            // Process each row in the CSV file
            String[] row;
            while ((row = reader.readNext()) != null) {
                LocalDate currentDate = LocalDate.parse(row[0], DATE_FORMATTER);
                double[] values = Arrays.stream(row).skip(1).mapToDouble(Double::parseDouble).toArray();

                // Update the sliding windows
                updateWindows(dateWindow, valueWindow, currentDate, values);

                // Calculate moving average if window is full
                if (dateWindow.size() == WINDOW_SIZE) {
                    sumValues = calculateSum(valueWindow);
                    double[] movingAverages = Arrays.stream(sumValues).map(s -> s / WINDOW_SIZE).toArray();

                    // Write results to output file
                    String[] outputRow = createOutputRow(currentDate, movingAverages);
                    writer.writeNext(outputRow);
                }
            }
        }
    }

    // Update the date and value windows for moving average calculation
    private static void updateWindows(Deque<LocalDate> dateWindow, Deque<double[]> valueWindow,
                                      LocalDate currentDate, double[] values) {
        dateWindow.add(currentDate);
        valueWindow.add(values);

        // Maintain window size
        if (dateWindow.size() > WINDOW_SIZE) {
            dateWindow.removeFirst();
            valueWindow.removeFirst();
        }
    }

    // Calculate the sum of values in the window for each column
    private static double[] calculateSum(Deque<double[]> valueWindow) {
        int numColumns = valueWindow.peekFirst().length;
        double[] sumValues = new double[numColumns];
        for (double[] values : valueWindow) {
            for (int i = 0; i < numColumns; i++) {
                sumValues[i] += values[i];
            }
        }
        return sumValues;
    }

    // Create the output row with date and calculated moving averages
    private static String[] createOutputRow(LocalDate currentDate, double[] movingAverages) {
        String[] outputRow = new String[movingAverages.length + 1];
        outputRow[0] = currentDate.format(DATE_FORMATTER);
        for (int i = 0; i < movingAverages.length; i++) {
            outputRow[i + 1] = String.format("%.2f", movingAverages[i]);
        }
        return outputRow;
    }
}